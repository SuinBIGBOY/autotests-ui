import allure
from playwright.sync_api import Page, Playwright
from typing import Generator
from config import settings, Browser
from tools.playwright.mocks import mock_static_resources


def initialize_playwright_page(
        playwright: Playwright,
        test_name: str,
        browser_type: Browser,
        storage_state: str | None = None,
) -> Generator[Page, None, None]:

    browser = playwright[browser_type].launch(headless=settings.headless)
    context = browser.new_context(
        storage_state=storage_state, record_video_dir=settings.videos_dir, base_url=settings.get_base_url()
    )
    context.tracing.start(screenshots=True, snapshots=True, sources=True)
    page = context.new_page()
    mock_static_resources(page)

    yield page

    context.tracing.stop(path=settings.tracing_dir.joinpath(f"{test_name}.zip"))
    context.close()
    browser.close()

    allure.attach.file(settings.tracing_dir.joinpath(f"{test_name}.zip"), name="trace", extension="zip")
    allure.attach.file(page.video.path(), name="video", attachment_type=allure.attachment_type.WEBM)